from flask import *
import datetime as dt
import pandas as pd
from pymongo import MongoClient

app = Flask(__name__)
client =MongoClient("mongodb+srv://ADS:123@cluster0.ovb90gs.mongodb.net/?retryWrites=true&w=majority")
db=client["reception_data"]
mycol = db["user_data"]

@app.route('/', methods=["GET","POST"])
def index():
    if request.method == 'POST':
        values = request.form.to_dict()
        data = {
            "Name": [values["name"]],
            "Purpose": [values["purpose"]],
            "Time": [dt.datetime.now()],
            "Visitors": [values["visitors"]]
        }
        name=request.form["name"]
        purpose=request.form["purpose"]
        tim=dt.datetime.now()
        visitor=request.form["visitors"]
        d={"name":name,"purpose":purpose,"time":tim,"visitors":visitor}
        mycol.insert_one(d)
        
        # df = pd.read_excel("details.xlsx",engine="openpyxl")
        # df = df.dropna(axis=0,how="all")
        # df1 = pd.DataFrame(data,index=None)
        # df = pd.concat([df,df1])
        # df.to_excel("details.xlsx",index=False)
        
        return render_template("success.html")
        
    else:
        return render_template("index.html")
    
if __name__ == '__main__':
    app.run(host="0.0.0.0",port=8020,debug=True)
