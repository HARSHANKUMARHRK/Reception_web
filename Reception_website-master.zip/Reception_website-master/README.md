# Reception_website

## Install requirements
```
pip install -r requirements.txt
```

## Run app.py
```
python app.py
```
